package com.group5.ide_vss.object;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.group5.ide_vss.data.dataServices;
import com.group5.ide_vss.utils.UtilPi;
import com.group5.ide_vss.utils.UtilDirectory;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;

public class App {

    private String fileName;
    private String appName;
    private String workingDirectory;
    private Unit[] units;
    private String originJson;

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getWorkingDirectory() {
        return workingDirectory;
    }

    public void setWorkingDirectory(String workingDirectory) {
        this.workingDirectory = workingDirectory;
    }

    public Unit[] getUnits() {
        return units;
    }

    public void setUnits(Unit[] units) {
        this.units = units;
    }

    public String getOriginJson() {
        return originJson;
    }

    public void setOriginJson(String originJson) {
        this.originJson = originJson;
    }

    @Override
    public String toString() {
        return "App{" +
                "fileName='" + fileName + '\'' +
                ", appName='" + appName + '\'' +
                ", workingDirectory='" + workingDirectory + '\'' +
                ", units=" + Arrays.toString(units) +
                ", originJson='" + originJson + '\'' +
                '}';
    }

    public App(String json) throws JsonProcessingException {
        this.workingDirectory = UtilDirectory.workingDirectory;
        this.originJson = json;
        ObjectMapper mapper = new ObjectMapper();
        JsonNode node = mapper.readTree(json);
        this.appName = node.get("appname").asText();
        this.fileName = appName + ".json";
        JsonNode unitOfNode = node.get("units");
        units = new Unit[unitOfNode.size()];
        int index = 0;
        for (JsonNode curNode : unitOfNode) {
            Service one = dataServices.services.getOrDefault(curNode.get("pre").asText(), null), two = dataServices.services.getOrDefault(curNode.get("post").asText(), null);
            units[index++] = new Unit(one, curNode.get("prepara").asText(), curNode.get("value").asText(), two, curNode.get("postpara").asText());
        }
    }

    public void run() throws IOException {
        int index = 1;
        for (Unit unit : units) {
            System.out.println("Running unit " + index++);
            unit.run();
        }
    }

    class Unit {
        Service pre;
        String prePara;
        String value; // int, bool, or string?
        Service post;
        String postPara;

        public Unit(Service pre, String prePara, String value, Service post, String postPara) {
            this.pre = pre;
            this.prePara = prePara;
            this.value = value;
            this.post = post;
            this.postPara = postPara;
        }

        public void run() throws IOException {
            if (pre == null) {
                String result = post.call("(" + postPara + ")");
                System.out.println("Service result is: " + result);
                return;
            }
            if (pre.call("(" + prePara + ")").equals(value)) {
                String result = post.call("(" + postPara + ")");
                System.out.println("Service result is: " + result);
            }
        }
    }
    public void saveApp() throws IOException {
        File file = new File(this.workingDirectory + "/" + this.fileName);
        System.out.println(file.getAbsolutePath());
        FileWriter writer = new FileWriter(file);
        System.out.println(this.originJson);
        writer.write(this.originJson);
        writer.close();
    }

    public void deleteApp() {
        File myObj = new File(this.workingDirectory + "/" + this.fileName);
        if (myObj.delete()) {
            System.out.println("Deleted the file: " + myObj.getName());
        } else System.out.println("Failed to delete the file.");
    }
}

