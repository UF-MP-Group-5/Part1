package com.group5.ide_vss.utils;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.group5.ide_vss.data.dataServices;
import com.group5.ide_vss.object.Service;
import com.group5.ide_vss.object.Thing;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.util.ArrayList;
import java.util.List;

public class UtilPi {

    public static void getTweetsFromPi() {
        try{
            System.out.println("haha");
            MulticastSocket ms = new MulticastSocket(1235);
            InetAddress ia = InetAddress.getByName("232.1.1.1");
            ms.joinGroup(ia);
            byte[] buffer = new byte[4096];
            List<String> thinglist = new ArrayList<String>();
            List<String> tStatus = new ArrayList<String>();
            int thingcount = 0;
            tStatus.add("stop");
            tStatus.add("stop");
            tStatus.add("stop");
            tStatus.add("stop");
            tStatus.add("stop");
            while (true) {
                DatagramPacket dp = new DatagramPacket(buffer, buffer.length);
                ms.receive(dp);
                String s = new String(dp.getData());
                //String ss = rtweets.get("Space ID").asText();
                //SmartSpace@Group5 
                if(s.contains("SmartSpaceGroup5")) {
                    System.out.println(s);
                    ObjectMapper mapper = new ObjectMapper();
                    JsonNode rtweets = mapper.readTree(s);
                    String tid = rtweets.get("Thing ID").asText();
                    String strs[] = tid.split("0");
                    int i = Integer.parseInt(strs[1]);
                    if(rtweets.get("Tweet Type").asText().equals("Identity_Thing")) { //first tweet of each loop
                        if (!thinglist.contains(tid)) {
                            thinglist.add(tid);
                            tStatus.set(i, "activate");
                            String ip0 = dp.getAddress().toString();
                            int port0 = dp.getPort();
                            System.out.println(tid + s);
                            Thing thi0 = new Thing(rtweets.get("Thing ID").asText(), rtweets.get("Space ID").asText(), rtweets.get("Name").asText(), rtweets.get("Model").asText(), rtweets.get("Vendor").asText(), rtweets.get("Owner").asText(), rtweets.get("Description").asText(), rtweets.get("OS").asText());
                            dataServices.things.put(thi0.getThing_id(), thi0);
                        }else {
                            System.out.println("again"+ tid + s);
                            tStatus.set(i, "stop");
                            thingcount++;
                            System.out.println("finished listening to" + tid);
                        }
                    }else {//other tweets
                        if(thinglist.contains(tid) && tStatus.get(i).equals("activate")) {
                            System.out.println("***"+ tid + s);
                            if(rtweets.get("Tweet Type").asText().equals("Service")) {
                                String ip0 = dp.getAddress().getHostAddress();
                                Service serv0 = new Service(ip0, rtweets.get("Name").asText(), rtweets.get("Thing ID").asText(), rtweets.get("Entity ID").asText(), rtweets.get("Space ID").asText(), rtweets.get("Vendor").asText(), rtweets.get("API").asText(), rtweets.get("Type").asText(), rtweets.get("AppCategory").asText(), rtweets.get("Description").asText(), rtweets.get("Keywords").asText() );
                                dataServices.services.put(serv0.getName(), serv0);
                            }

                        }
                    }
                }
                if (thingcount == 4) {
                    System.out.println("all tweets are received");
                    break;
                }

            }
        }
        catch (IOException ex){
            System.err.println(ex);
        }
    }

    public static void testForJson() throws IOException {
//        String ss = "{\"appname\":\"abcdef\",\"units\":\"hihihi\"}";
//        String a1 = "{" + "\"objects\" : [\"One\", \"Two\", \"Three\"]" + "}";

//        dataServices.services.put("Get_Temperature_C", new Service("192.168.0.172", "6668", "Hao01", "HaoSpace01", "Get_Temperature_C", "This is a category", "This is a type", "This is a keywords", "This is a description"));
//        dataServices.services.put("Get_Humidity", new Service("192.168.0.172", "6668", "Hao01", "HaoSpace01", "Get_Humidity", "This is a category", "This is a type", "This is a keywords", "This is a description"));
//        dataServices.services.put("Get_Soil_State", new Service("192.168.0.172", "6668", "Hao01", "HaoSpace01", "Get_Soil_State", "This is a category", "This is a type", "This is a keywords", "This is a description"));
//        dataServices.services.put("Light_Time", new Service("192.168.0.172", "6668", "Hao01", "HaoSpace01", "Light_Time", "This is a category", "This is a type", "This is a keywords", "This is a description"));
//        dataServices.services.put("Tap_Times", new Service("192.168.0.172", "6668", "Hao01", "HaoSpace01", "Tap_Times", "This is a category", "This is a type", "This is a keywords", "This is a description"));
//        System.out.println(dataServices.services.get("bbb").call("()"));
//        String s = "{\"appname\":\"HelloWorld\",\"units\":[{\"pre\":\"null\", \"prepara\":\"\", \"value\":\"\",\"post\":\"aaa\", \"postpara\":\"\"},{\"pre\":\"bbb\", \"prepara\":\"\", \"value\":\"65\", \"post\":\"ddd\", \"postpara\":\"5\"},{\"pre\":\"ccc\", \"prepara\":\"\", \"value\":\"0\", \"post\":\"eee\", \"postpara\":\"10\"}]}";
//        String ss = "[{\"pre\":\"null\", \"prepara\":\"\", \"value\":\"\",\"post\":\"aaa\", \"postpara\":\"\"},{\"pre\":\"bbb\", \"prepara\":\"\", \"value\":\"62\", \"post\":\"ddd\", \"postpara\":\"5\"},{\"pre\":\"ccc\", \"prepara\":\"\", \"value\":\"0\", \"post\":\"eee\", \"postpara\":\"10\"}]";
//        System.out.println(s);
//        App app = new App(s);
//        app.run();
    }
}
