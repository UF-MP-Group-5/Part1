package com.group5.ide_vss;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IdeVssApplicationTests {

    @Test
    void contextLoads() {
    }

}
