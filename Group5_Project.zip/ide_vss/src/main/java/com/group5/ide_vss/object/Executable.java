package com.group5.ide_vss.object;

import java.io.IOException;

public interface Executable {
    String call(String inputs) throws IOException;
}
